# Multi-Agent 协同系统

前端和后端完整示例，升级前端可实时显示Agent状态和任务结果。