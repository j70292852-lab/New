import threading, time, random

class Agent(threading.Thread):
    def __init__(self, name, task_queue, result_queue):
        super().__init__()
        self.name = name
        self.task_queue = task_queue
        self.result_queue = result_queue
        self.running = True

    def run(self):
        while self.running:
            try:
                task = self.task_queue.get(timeout=1)
            except:
                continue
            self.result_queue.put((self.name, self.execute_task(task)))
            self.task_queue.task_done()

    def execute_task(self, task):
        time.sleep(random.uniform(0.5, 2))
        return f"{task} completed"

    def stop(self):
        self.running = False
