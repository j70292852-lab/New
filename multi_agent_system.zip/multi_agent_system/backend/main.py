from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import threading, queue, time, random
from agent import Agent
from coordinator import Coordinator

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

task_queue = queue.Queue()
result_queue = queue.Queue()
agents = [Agent(f"Agent-{i}", task_queue, result_queue) for i in range(3)]
coordinator = Coordinator(agents, task_queue, result_queue)

for agent in agents:
    agent.start()

class TaskRequest(BaseModel):
    task_name: str

@app.post("/add_task")
def add_task(request: TaskRequest):
    task_queue.put(request.task_name)
    return {"status": "Task added", "task": request.task_name}

@app.get("/results")
def get_results():
    results = []
    while not result_queue.empty():
        results.append(result_queue.get())
    return {"results": results}
