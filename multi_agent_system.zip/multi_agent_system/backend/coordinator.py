class Coordinator:
    def __init__(self, agents, task_queue, result_queue):
        self.agents = agents
        self.task_queue = task_queue
        self.result_queue = result_queue
