const apiUrl = "http://127.0.0.1:8000";
let agentsState = {};

async function addTask() {
    const taskName = document.getElementById("taskName").value;
    if (!taskName) return alert("请输入任务名");
    const res = await fetch(`${apiUrl}/add_task`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({task_name: taskName})
    });
    document.getElementById("taskName").value = "";
}

async function updateResults() {
    const res = await fetch(`${apiUrl}/results`);
    const data = await res.json();

    const resultsEl = document.getElementById("results");
    resultsEl.innerHTML = "";
    data.results.forEach(r => {
        resultsEl.innerHTML += `<li>[${r[0]}] -> ${r[1]}</li>`;
        agentsState[r[0]] = "空闲";
    });

    const agentsEl = document.getElementById("agentsStatus");
    agentsEl.innerHTML = "";
    Object.keys(agentsState).forEach(agent => {
        agentsEl.innerHTML += `<li>${agent}: ${agentsState[agent]}</li>`;
    });
}

function initAgents(agentCount = 3) {
    for (let i = 0; i < agentCount; i++) {
        agentsState[`Agent-${i}`] = "空闲";
    }
}

setInterval(updateResults, 1000);
initAgents();
